################################################################################
#
# Package   : AlphaPy
# Module    : analysis
# Created   : July 11, 2013
#
# Copyright 2019 ScottFree Analytics LLC
# Mark Conway & Robert D. Scott II
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
################################################################################


#
# Imports
#

from alphapy.alphapy_main import main_pipeline
from alphapy.frame import write_frame
from alphapy.globals import PSEP, SSEP, USEP
from alphapy.utilities import subtract_days

from datetime import timedelta
import logging
import pandas as pd
from pandas.tseries.offsets import BDay


#
# Initialize logger
#

logger = logging.getLogger(__name__)


#
# Function analysis_name
#

def analysis_name(gname, target):
    r"""Get the name of the analysis.

    Parameters
    ----------
    gname : str
        Group name.
    target : str
        Target of the analysis.

    Returns
    -------
    name : str
        Value for the corresponding key.

    """
    name = USEP.join([gname, target])
    return name


#
# Class Analysis
#

class Analysis(object):
    """Create a new analysis for a group. All analyses are stored
    in ``Analysis.analyses``. Duplicate keys are not allowed.

    Parameters
    ----------
    model : alphapy.Model
        Model object for the analysis.
    group : alphapy.Group
        The group of members in the analysis.

    Attributes
    ----------
    Analysis.analyses : dict
        Class variable for storing all known analyses

    """

    analyses = {}

    # __new__

    def __new__(cls,
                model,
                group):
        # set analysis name
        name = model.specs['directory'].split(SSEP)[-1]
        target = model.specs['target']
        an = analysis_name(name, target)
        if not an in Analysis.analyses:
            return super(Analysis, cls).__new__(cls)
        else:
            logger.info("Analysis %s already exists", an)

    # function __init__

    def __init__(self,
                 model,
                 group):
        # set analysis name
        name = model.specs['directory'].split(SSEP)[-1]
        target = model.specs['target']
        an = analysis_name(name, target)
        # initialize analysis
        self.name = an
        self.model = model
        self.group = group
        # add analysis to analyses list
        Analysis.analyses[an] = self

    # __str__

    def __str__(self):
        return self.name


#
# Function run_analysis
#

def run_analysis(analysis, dfs, fractals, forecast_period, predict_history):
    r"""Run an analysis for a given model and group.

    First, the data are loaded for each member of the analysis group.
    Then, the target value is lagged for the ``forecast_period``, and
    any ``leaders`` are lagged as well. Each frame is split along
    the ``predict_date`` from the ``analysis``, and finally the
    train and test files are generated.

    Parameters
    ----------
    analysis : alphapy.Analysis
        The analysis to run.
    dfs : list
        The list of pandas dataframes to analyze.
    fractals : list
        List of Pandas offset aliases.
    forecast_period : int
        The period for forecasting the target of the analysis.
    predict_history : int
        The number of periods required for lookback calculations.

    Returns
    -------
    analysis : alphapy.Analysis
        The completed analysis.

    """

    # Unpack analysis
    model = analysis.model

    # Unpack model data

    predict_file = model.predict_file
    test_file = model.test_file
    train_file = model.train_file

    # Unpack model specifications

    directory = model.specs['directory']
    extension = model.specs['extension']
    leaders = model.specs['leaders']
    predict_date = model.specs['predict_date']
    predict_mode = model.specs['predict_mode']
    separator = model.specs['separator']
    target = model.specs['target']
    train_date = model.specs['train_date']

    # Calculate split date
    logger.info("Analysis Dates")
    split_date = subtract_days(predict_date, predict_history)

    # Create dataframes

    if predict_mode:
        # create predict frame
        logger.info("Split Date for Prediction Mode: %s", split_date)
        predict_frame = pd.DataFrame()
    else:
        # create train and test frames
        logger.info("Split Date for Training Mode: %s", predict_date)
        train_frame = pd.DataFrame()
        test_frame = pd.DataFrame()

    # Determine whether or not we are predicting with the base fractal or a higher fractal

    base_fractal = fractals[0]
    target_fractal = target.split('.')[0]
    base_prediction = True if base_fractal == target_fractal else False

    # Subset each individual frame and add to the master frame

    for df in dfs:
        symbol = df['symbol'].iloc[0]
        first_date = df.index[0]
        last_date = df.index[-1]
        logger.info("Analyzing %s from %s to %s", symbol.upper(), first_date, last_date)
        # shift target and leaders
        if base_prediction:
            df[target] = df[target].shift(-forecast_period)
            df[leaders] = df[leaders].shift(-forecast_period)
        else:
            fractal_shift = df.groupby(pd.Grouper(freq=target_fractal)).count().iloc(0)[0][0]
            df[target] = df[target].shift(-fractal_shift)
            df[leaders] = df[leaders].shift(-fractal_shift)
            df = df.groupby(pd.Grouper(freq=target_fractal)).nth(forecast_period-1)
        # get frame subsets
        if predict_mode:
            new_predict = df.loc[(df.index >= split_date) & (df.index <= last_date)]
            if len(new_predict) > 0:
                predict_frame = predict_frame.append(new_predict)
            else:
                logger.info("Prediction frame %s has zero rows. Check prediction date.", symbol)
        else:
            # split data into train and test
            new_train = df.loc[(df.index >= train_date) & (df.index < predict_date)]
            if len(new_train) > 0:
                new_train = new_train.dropna()
                train_frame = train_frame.append(new_train)
                new_test = df.loc[(df.index >= predict_date) & (df.index <= last_date)]
                if len(new_test) > 0:
                    # check if target column has NaN values
                    nan_count = df[target].isnull().sum()
                    forecast_check = forecast_period - 1
                    if nan_count != forecast_check:
                        logger.info("%s has %d records with NaN targets", symbol, nan_count)
                    # drop records with NaN values in target column
                    new_test = new_test.dropna(subset=[target])
                    # append selected records to the test frame
                    test_frame = test_frame.append(new_test)
                else:
                    logger.info("Testing frame %s has zero rows. Check prediction date.", symbol)
            else:
                logger.info("Training frame %s has zero rows. Check data source.", symbol)

    # Write out the frames for input into the AlphaPy pipeline

    directory = SSEP.join([directory, 'input'])
    if predict_mode:
        # write out the predict frame
        write_frame(predict_frame, directory, predict_file, extension, separator,
                    index=True, index_label='date')
    else:
        # write out the train and test frames
        write_frame(train_frame, directory, train_file, extension, separator,
                    index=True, index_label='date')
        write_frame(test_frame, directory, test_file, extension, separator,
                    index=True, index_label='date')

    # Run the AlphaPy pipeline
    analysis.model = main_pipeline(model)

    # Return the analysis
    return analysis

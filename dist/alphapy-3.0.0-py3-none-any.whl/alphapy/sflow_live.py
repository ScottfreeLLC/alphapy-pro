import pandas as pd
from alphapy.globals import SSEP, USEP

# Read in the Live Results file.

directory = '/Users/markconway/Projects/alphapy-root/alphapy-sports/MLB/Projects/won_on_points/output'
file_spec = 'live_results.csv'
df_live = pd.read_csv(SSEP.join([directory, file_spec]))
print(df_live.columns)

# Input Parameters

capital = 10000
prob_cols = ['prob_test_blend', 'prob_test_ts_blend']
kelly_frac = 0.5
ml_min = 150

# Calculate winning percentages and probability deltas.

def get_odds(x):
    if x > 0:
        odds = x / 100.0 + 1.0
    elif x < 0:
        odds = 100.0 / abs(x) + 1.0
    else:
        odds = 0.0
    return odds

def get_prob_win(x):
    if x > 0:
        prob = 1.0 - (x / (x + 100.0))
    elif x < 0:
        prob = abs(x) / (abs(x) + 100.0)
    else:
        prob = 0.5
    return prob

def get_kelly_pct(row, side):
    colname = USEP.join([side, 'odds'])
    odds = row[colname]
    colname = USEP.join([side, 'prob', 'win'])
    prob_win = row[colname]
    prob_model = row[prob_col]
    if side == 'home':
        kelly_pct = ((odds - 1.0) * prob_win - (1.0 - prob_model)) / (odds - 1.0) * kelly_frac
    elif side == 'away':
        kelly_pct = ((odds - 1.0) * prob_win - prob_model) / (odds - 1.0) * kelly_frac
    return kelly_pct

if not df_live.empty:
    # calculate odds and win probability
    for side in ['away', 'home']:
        col_ml = USEP.join([side, 'money', 'line'])
        mlclose = df_live[col_ml]
        col_odds = USEP.join([side, 'odds'])
        df_live[col_odds] = mlclose.apply(get_odds)
        col_pw = USEP.join([side, 'prob', 'win'])
        df_live[col_pw] = mlclose.apply(get_prob_win)
        for prob_col in prob_cols:
            colname = USEP.join([side, prob_col, 'delta'])
            if side == 'home':
                df_live[colname] = df_live[prob_col] - df_live[col_pw]
            elif side == 'away':
                df_live[colname] = (1.0 - df_live[prob_col]) - df_live[col_pw]
            colname = USEP.join([side, prob_col, 'kelly', 'pct'])
            df_live[colname] = df_live.apply(get_kelly_pct, args=(side,), axis=1)
    # save results
    file_spec = 'kelly_results.csv'
    df_live.to_csv(SSEP.join([directory, file_spec]))
    # Betting System Analysis
    if ml_min:
        df_bet = df_live.loc[(df_live['away_money_line'].abs() >= ml_min) | (df_live['home_money_line'].abs() >= ml_min)].copy()
    working_cap = capital
    for index, row in df_bet.iterrows():
        if row['away_money_line'] >= ml_min:
            pass
        if row['home_money_line'] >= ml_min:
            pass
